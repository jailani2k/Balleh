/*
 * *
 *  Copyright © 2016 Magestore. All rights reserved.
 *  See COPYING.txt for license details.
 *  
 */
define(
    [
        'jquery',
        'uiComponent',
        'ko',
        'mage/translate',
        'Magento_Checkout/js/model/quote',
        'Magestore_OneStepCheckout/js/action/validate-shipping-info',
        'Magestore_OneStepCheckout/js/action/showLoader',
        'Magestore_OneStepCheckout/js/action/save-shipping-address',
        'Magestore_OneStepCheckout/js/action/set-shipping-information',
        'Magestore_OneStepCheckout/js/model/shipping-rate-service',
        'Magestore_OneStepCheckout/js/action/save-additional-information',
        'Magento_Ui/js/modal/alert',
        'Magestore_OneStepCheckout/js/view/gift-message'
    ],
    function (
        $,
        Component,
        ko,
        $t,
        quote,
        ValidateShippingInfo,
        Loader,
        SaveAddressBeforePlaceOrder,
        setShippingInformationAction,
        shippingRateService,
        saveAdditionalInformation,
        alertPopup,
        giftMessageView
    ) {
        'use strict';
        return Component.extend({
            defaults: {
                template: 'Magestore_OneStepCheckout/onestepcheckout'
            },
            errorMessage: ko.observable(),
            paymentMethodAllowPopup: ['braintree_paypal'],
            isVirtual:quote.isVirtual,
            enableCheckout: ko.pureComputed(function(){
                return (Loader.loading())?false:true;
            }),
            placingOrder: ko.observable(false),
            initialize: function () {
                this._super();
            },
            prepareToPlaceOrder: function(){
				/*var payment = quote.paymentMethod();
                var paymentMethod = payment.method;
				if(paymentMethod == 'HyperPay_Master') {
					if(!this.ValidateCardDetails()){
						$('#card_error').css('display', 'inline');						
						setTimeout(function() {
							$("#card_error").hide('blind', {}, 500);
						}, 5000);				
						return false;
					}	
				}	*/
                var self = this;
               var payment = quote.paymentMethod();
                var paymentMethod = payment.method;
				var pn = $("input[name='payment[method]']:checked").val();				
                if (!quote.paymentMethod() || pn == undefined) { 
                    alertPopup({
                        content: $t('Please choose a payment method!'),
                        autoOpen: true,
                        clickableOverlay: true,
                        focus: "",
                        actions: {
                            always: function(){

                            }
                        }
                    });
					
					$('html, body').animate({
						scrollTop: ($('li.payment-method').first().offset().top)
					},500);
                }
                if(self.validateInformation() == true){
                    self.placingOrder(true);
                    Loader.all(true);
                    var deferred = saveAdditionalInformation();
                    var payment = quote.paymentMethod();
                    var paymentMethod = payment.method;
                    if (self.paymentMethodAllowPopup.indexOf(paymentMethod) > -1) {
                        self.placeOrder();
                    } else {
                        deferred.done(function () {
                            if ($('#allow_gift_messages').length > 0) {
                                var giftMessageDeferred;
                                if ($('#allow_gift_messages').attr('checked') == 'checked') {
                                    giftMessageDeferred = giftMessageView().submitOptions();
                                    giftMessageDeferred.done(function () {
                                        self.placeOrder();
                                    });
                                } else {
                                    giftMessageDeferred = giftMessageView().deleteOptions();
                                    giftMessageDeferred.done(function () {
                                        self.placeOrder();
                                    });
                                }
                            } else {
                                self.placeOrder();
                            }
                        });
                    }
                }else{
                    //false
                }
            },

            placeOrder: function () {
                var self = this;
                var payment = quote.paymentMethod();
                var paymentMethod = payment.method;
                var checkoutButton = $("#co-payment-form ._active button[type='submit']");
                SaveAddressBeforePlaceOrder();
                if(this.isVirtual()){
                    if(checkoutButton.length > 0){
                        if (paymentMethod == 'braintree_paypal') {
                            self.braintreePaypalCheckout();
                        } else {
                            checkoutButton.click();
                        }
                        self.placingOrder(false);
                        Loader.all(false);
                    }
                }else{
                    if (self.paymentMethodAllowPopup.indexOf(paymentMethod) > -1) {
                        setShippingInformationAction().always(
                            function () {
                                shippingRateService().stop(false);
                            }
                        );
                        if(checkoutButton.length > 0){
                            if (paymentMethod == 'braintree_paypal') {
                                self.braintreePaypalCheckout();
                            } else {
                                checkoutButton.click();
                            }

                            self.placingOrder(false);
                            Loader.all(false);
                        }
                    } else {
                        setShippingInformationAction().always(
                            function () {
                                shippingRateService().stop(false);
                                if(checkoutButton.length > 0){
                                    checkoutButton.click();
                                    self.placingOrder(false);
                                    Loader.all(false);
                                }
                            }
                        );
                    }
                }
            },

            validateInformation: function(){
				$('html, body').animate({
					scrollTop: ($('li.payment-method').first().offset().top)
				},500);
				
                var shipping = (this.isVirtual())?true:ValidateShippingInfo();
                var billing = this.validateBillingInfo();
                return shipping && billing;
            },
            
            afterRender: function(){
                $('#checkout-loader').removeClass('show');
            },
            
            validateBillingInfo: function(){
                if($("#co-payment-form ._active button[type='submit']").length > 0){
                    if($("#co-payment-form ._active button[type='submit']").hasClass('disabled')){
                        if($("#co-payment-form ._active button.update-address-button").length > 0){
                            this.showErrorMessage($t('Please update your billing address'));
                        }
                        return false;
                    }else{
                        return true;
                    }
                }
                return false;
            },
            showErrorMessage: function(message){
                var self = this;
                var timeout = 5000;
                self.errorMessage($t(message));
                setTimeout(function(){
                    self.errorMessage('');
                },timeout);
            },

            braintreePaypalCheckout: function () {
                var checkoutButton = $("#co-payment-form ._active button[type='submit']");
                var element = checkoutButton.get(0);
                var viewModel = ko.dataFor(element);

                if ($('.payment-method-description').is(":visible")) {
                    viewModel.placeOrder();
                } else {
                    viewModel.payWithPayPal();
                }
            }  /*,
			ValidateCardDetails: function() {
				
				var cn_hidden = $('#card_number_hidden').val();
				var cv_hidden = $('#card_cvv_hidden').val();
				var cd_holder = $('#card_holder').val();				
				var err = 0;
				
				var exMonth = $( "#card_expiryMonth option:selected" ).val();
				var exYear = $( "#card_expiryYear option:selected" ).val();
				var today, someday;
				today = new Date();
				someday = new Date();
				someday.setFullYear(exYear, exMonth, 1);

				if(cn_hidden == 0) {
					$('#card_error_while').html('<span class ="error"> الرجاء التحقق من رقم البطاقة </span>');
					err = 1;
				} else if(cd_holder.length < 1) {
					err = 1;
					$('#card_error_while').html('<span class ="error"> الرجاء ادخال اسم العميل كما يظهر على البطاقة </span>');
				} else if (someday < today) {
					err = 1;
					$('#card_error_while').html('<span class ="error"> الرجاء التحقق من تاريخ الانتهاء </span>');
				} else if(cv_hidden == 0) {
					err = 1;
					$('#card_error_while').html('<span class ="error"> الرجاء التحقق من رمز البطاقة </span>');
				} 	
				
				if(err == 1) {
					$('#card_error_while').css("display", "block");
					setTimeout(function() {
						$("#card_error_while").hide('blind', {}, 500);
					}, 5000);
				}	
							
				//if(cn_hidden == 1 && cx_hidden  == 1 && cv_hidden == 1)
				if(err == 0)
					return true;
				
				
				return false;
			} */
			
			/*
			$('#co-shipping-form [name="telephone"]').keyup(function(e){ // console.log($('#co-shipping-form [name="telephone"]').val());
				var arabics = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
				var engs = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
				 var insideText = String.fromCharCode(e.which);
				  var index = engs.indexOf(insideText);
				  if (index >= 0) {
					var value = $('#co-shipping-form [name="telephone"]').val();
					value = value.replace(insideText, arabics[index]);
					// $('#co-shipping-form [name="telephone"]').val(value);
					console.log(value);
				  }
				
			}); */
	
        });
    }
);
