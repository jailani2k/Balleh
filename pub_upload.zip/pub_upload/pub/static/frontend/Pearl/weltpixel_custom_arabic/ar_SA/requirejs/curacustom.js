require([ "jquery" ], function($){

	$(window).scroll(function () {
		if( $(window).scrollTop() > $('.page-header').offset().top && !($('.page-header').hasClass('sticky')) && $(window).width() < 768){
			$('.page-header').addClass('sticky');
		} else if ($(window).scrollTop() == 0){
			$('.page-header').removeClass('sticky');
		}
	});
	
	$( document ).ready(function() {
		var tx = $(".product-info-main .page-title-wrapper .brand_name").text()+' '+$(".product-info-main .page-title-wrapper .page-title").text();	
		$(".product-info-main .page-title-wrapper .page-title").text(tx);	

		if($(window).width() < 768){			
			setTimeout(function(){
			   $("#search_mini_form").show();
			}, 5000);
		}		
	});
});