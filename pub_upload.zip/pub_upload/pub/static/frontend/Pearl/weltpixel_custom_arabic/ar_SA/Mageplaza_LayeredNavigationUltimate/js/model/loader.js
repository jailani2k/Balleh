/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license sliderConfig is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_LayeredNavigationUltimate
 * @copyright   Copyright (c) 2017 Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

define(
    [
        'jquery'
    ],
    function ($) {
        'use strict';

        return {
            /**
             * Start full page loader action
             */
            startLoader: function () {
                if (!$('#ln_product_overlay').length) {
                    var lnOverlay = $('#ln_overlay').html(),
                        lnProductOverlay = $('<div></div>', {id: 'ln_product_overlay'}).css('display', 'none').css('text-align', 'center').html(lnOverlay);

                    $('#layer-product-list').append(lnProductOverlay);
                }
				
                $('#ln_product_overlay').show();
				$("img.lazy").lazyload();
				
            },

            /**
             * Stop full page loader action
             */
            stopLoader: function () {
                $('#ln_product_overlay').hide();
				$("img.lazy").lazyload();
				var whishlist_position = '.whishlist_position_2';
                var productItem = '.products-grid .product-item';
                var productImageAction = '.product_image .actions .actions-secondary';	
				var btn	= '';
				$(productItem).each(function () {
					var el = $(this),
						btn = el.find(whishlist_position);

					el.find(productImageAction).append(btn);
				});
				
					
				$("form[data-role='tocart-form']").catalogAddToCart();
				
            }
        };
    }
);
