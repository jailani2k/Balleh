/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
define(
        [
            'ko',
            'jquery',
            'uiComponent',
            'Magento_Checkout/js/action/place-order',
            'Magento_Checkout/js/action/select-payment-method',
            'Magento_Checkout/js/model/quote',
            'Magento_Customer/js/model/customer',
            'Magento_Checkout/js/model/payment-service',
            'Magento_Checkout/js/checkout-data',
            'Magento_Checkout/js/model/checkout-data-resolver',
            'uiRegistry',
            'Magento_Checkout/js/model/payment/additional-validators',
            'Magento_Ui/js/model/messages',
            'uiLayout',
			'Magento_Checkout/js/action/redirect-on-success',
            'mage/translate'			
        ],
        function (
                ko,
                $,
                Component,
                placeOrderAction,
                selectPaymentMethodAction,
                quote,
                customer,
                paymentService,
                checkoutData,
                checkoutDataResolver,
                registry,
                additionalValidators,
                Messages,
                layout,
				redirectOnSuccessAction
                ) {
            'use strict';			
			
            return Component.extend({
                redirectAfterPlaceOrder: true,
                options: {
                    processStart: null,
                },
                /**
                 * After place order callback
                 */
                afterPlaceOrder: function () {
                    //
                },
                isPlaceOrderActionAllowed: ko.observable(quote.billingAddress() != null),
                /**
                 * Initialize view.
                 *
                 * @returns {Component} Chainable.
                 */
                initialize: function () {
                    this._super().initChildren();
                    quote.billingAddress.subscribe(function (address) {
                        this.isPlaceOrderActionAllowed((address !== null));
                    }, this);
                    checkoutDataResolver.resolveBillingAddress();

                    var billingAddressCode = 'billingAddress' + this.getCode();
                    registry.async('checkoutProvider')(function (checkoutProvider) {
                        var defaultAddressData = checkoutProvider.get(billingAddressCode);
                        if (defaultAddressData === undefined) {
                            // skip if payment does not have a billing address form
                            return;
                        }
                        var billingAddressData = checkoutData.getBillingAddressFromData();
                        if (billingAddressData) {
                            checkoutProvider.set(
                                    billingAddressCode,
                                    $.extend({}, defaultAddressData, billingAddressData)
                                    );
                        }
                        checkoutProvider.on(billingAddressCode, function (billingAddressData) {
                            checkoutData.setBillingAddressFromData(billingAddressData);
                        }, billingAddressCode);
                    });

                    return this;
                },
                /**
                 * Initialize child elements
                 *
                 * @returns {Component} Chainable.
                 */
                initChildren: function () {
                    this.messageContainer = new Messages();
                    this.createMessagesComponent();

                    return this;
                },
                /**
                 * Create child message renderer component
                 *
                 * @returns {Component} Chainable.
                 */
                createMessagesComponent: function () {

                    var messagesComponent = {
                        parent: this.name,
                        name: this.name + '.messages',
                        displayArea: 'messages',
                        component: 'Magento_Ui/js/view/messages',
                        config: {
                            messageContainer: this.messageContainer
                        }
                    };

                    layout([messagesComponent]);

                    return this;
                },
                /**
                 * Place order.
                 */
                placeOrder: function (data, event) {
                    var self = this,
                            placeOrder;

                    if (event) {
                        event.preventDefault();
                    }

                    if (this.validate() && additionalValidators.validate()) {
                        this.isPlaceOrderActionAllowed(false);
                        //placeOrder = placeOrderAction(this.getData(), this.redirectAfterPlaceOrder, this.messageContainer);
                        placeOrder = placeOrderAction(this.getData(), this.messageContainer);

                        $.when(placeOrder).fail(function () {
                            self.isPlaceOrderActionAllowed(true);
                        }).done(
							function () {
								self.afterPlaceOrder();

								if (self.redirectAfterPlaceOrder) {
									redirectOnSuccessAction.execute();
								}
							}
						//this.afterPlaceOrder.bind(this)
						);
                        return true;
                    }
                    return false;
                },
				
			/*placeOrder: function (data, event) {
				var self = this;

				if (event) {
					event.preventDefault();
				}

				if (this.validate() && additionalValidators.validate()) {
					this.isPlaceOrderActionAllowed(false);

					this.getPlaceOrderDeferredObject()
						.fail(
							function () {
								self.isPlaceOrderActionAllowed(true);
							}
						).done(
							function () {
								self.afterPlaceOrder();

								if (self.redirectAfterPlaceOrder) {
									redirectOnSuccessAction.execute();
								}
							}
						);

					return true;
				}

				return false;
			}
				
			*/	
				
				
            selectPaymentMethod: function () {
                    selectPaymentMethodAction(this.getData());
                    checkoutData.setSelectedPaymentMethod(this.item.method);
                    return true;
                },
                isChecked: ko.computed(function () {
                    return quote.paymentMethod() ? quote.paymentMethod().method : null;
                }),
                isRadioButtonVisible: ko.computed(function () {
                    return paymentService.getAvailablePaymentMethods().length !== 1;
                }),
                /**
                 * Get payment method data
                 */
                getData: function () {
                    return {
                        "method": this.item.method,
                        "po_number": null,
                        "additional_data": null
                    };
                },
                /**
                 * Get payment method type.
                 */
                getTitle: function () {
                    return this.item.title;
                },
                /**
                 * Get payment method code.
                 */
                getCode: function () {
                    return this.item.method;
                },
                validate: function () {
                    return true;
                },
                getBillingAddressFormName: function () {
                    return 'billing-address-form-' + this.item.method;
                },
                disposeSubscriptions: function () {
                    // dispose all active subscriptions
                    var billingAddressCode = 'billingAddress' + this.getCode();
                    registry.async('checkoutProvider')(function (checkoutProvider) {
                        checkoutProvider.off(billingAddressCode);
                    });
                },
                /**
                 * Themecafe : Customization of OTP Verification
                 */
                getBlockLink : function (){
                    var link = window.config.TitleLink;
                    return $.mage.__(link.replace(/&quot;/g, '\"'));
                },
                getBlockTitle : function (){
					$('#otp-block').css("display", "block");
                    $('#open-otp-link').css("display", "none");
                    $('#response-success').css("display", "none");
                    $('#response-fail').css("display", "none");
					var Title = window.config.TitleLabel;
					return $.mage.__(Title.replace(/&quot;/g, '\"'));
				/*	var errorMsg = window.config.OTPSendErrorMessage;
                   
					console.log(Title);
					var tn = $('#co-shipping-form').find("[name=telephone]").val();
					if(isNaN(tn)) {
						$('#open-otp-label').removeClass('error').addClass('error');						
						return $.mage.__(errorMsg.replace(/&quot;/g, '\"'));
					} else {
						if(tn){
							$('#open-otp-label').removeClass('error');
							// return $.mage.__(Title.replace(/&quot;/g, '\"'))+' '+tn;
							return $.mage.__('Verify Your Mobile Number');
						} else {
							$('#open-otp-label').removeClass('error').addClass('error');						
							return $.mage.__(errorMsg.replace(/&quot;/g, '\"'));
						}	
					}	*/
						
                    // return $.mage.__(Title.replace(/&quot;/g, '\"'))+' '+tn;
                },
                getsendButtonText : function (){
                    return $.mage.__('Send');
                },
				getResendButtonText : function (){
                    return $.mage.__('Resend');
                },
                getVerifyButtonText : function (){
                    return $.mage.__('Verify');
                },
                getTagLine : function (){
                    return $.mage.__('You have to verify within 5 minutes, Otherwise OTP will expire.');
                },
                resendOtp: function () {
                    $('#otp-block').css("display", "block");
                    $('#open-otp-link').css("display", "none");
                    $('#response-success').css("display", "none");
                    $('#response-fail').css("display", "none");
					var errorMsg = window.config.OTPSendErrorMessage;
					var Title = window.config.TitleLabel;
					var tn = $('#co-shipping-form').find("[name=telephone]").val();
					
					if(isNaN(tn)) {
						$('#open-otp-label').removeClass('error').addClass('error');						
						return $.mage.__(errorMsg.replace(/&quot;/g, '\"'));
					} else {
						if(tn){
							$('#open-otp-label').removeClass('error');
							//$('#open-otp-label').html($.mage.__(Title.replace(/&quot;/g, '\"'))+' '+tn);
						} else {
							$('#open-otp-label').removeClass('error').addClass('error');						
							return $.mage.__(errorMsg.replace(/&quot;/g, '\"'));
						}	
					}
										
					$('.otp-send-button').attr("disabled", "disabled");
					setTimeout(function() {
						$('#resend').prop("disabled", false);
					}, 30000);
					
                    $.ajax({
                        url: window.config.OtpAjaxUrl,
                        //data : {'billingNumber':quote.billingAddress().telephone},
                        data : {'billingNumber':$('#co-shipping-form').find("[name=telephone]").val()},
                        showLoader: true,
                        success: function (res) {
                            $('#otp-message').css("display", "block");
                            if (res.success) {
                                var successMSG = window.config.OTPSendSuccessMessage;
                                if(successMSG!=""){
                                    var msg = $.mage.__(successMSG.replace(/&quot;/g, '\"'));
                                   // $('#otp-message').html('<div class="message-success success message"><div>'+msg+'</div></div>');
								   $('#open-otp-label').html('<div class="message-success success message"><div>'+msg+' '+tn+'</div></div>');
                                }
                            } else {
                                var errorMessage = window.config.OTPSendErrorMessage;
                                if(errorMessage!=""){
                                    var msg = $.mage.__(errorMessage.replace(/&quot;/g, '\"'));
                                   $('#otp-message').html('<div class="message-error error message"><div>'+msg+'</div></div>');
                                }
                            }
                            setTimeout(function() {
                                $("#otp-message").hide('blind', {}, 500);
                            }, 5000);
                        }
                    });
                },
                verifyOtp: function () {
                    $('#otp-message').css("display", "none");
                    $.ajax({
                        url: window.config.OtpVerifyAjaxUrl,
                        //data: {otpvalue: $('#otpvalue').val(),'billingNumber':quote.billingAddress().telephone},
                        data: {otpvalue: $('#otpvalue').val(),'billingNumber':$('#co-shipping-form').find("[name=telephone]").val()},
                        type: 'post',
                        dataType: 'json',
                        showLoader: true,
                        success: function (res) {
                            if (res.response) {
                                $('#response-success').css("display", "inline-block");
                                $('#response-fail').css("display", "none");
                            } else {
                                $('#response-success').css("display", "none");
                                $('#response-fail').css("display", "inline-block");
                            }
                        }
                    });
                },
                isEnableOTP: function () {
                    return window.config.isEnable;
                }
            });
			/*
			$('#co-shipping-form input[name=telephone]').change(function() {
				var tn = $(this).val();
				console.log('vvvvvvv'+tn);
				if(isNaN(tn)) {
					$('#open-otp-label').removeClass('error').addClass('error');						
					return $.mage.__(errorMsg.replace(/&quot;/g, '\"'));
				} else {
					if(tn){
						$('#open-otp-label').removeClass('error');
						// return $.mage.__(Title.replace(/&quot;/g, '\"'))+' '+tn;
						return $.mage.__('Verify Your Mobile Number');
					} else {
						$('#open-otp-label').removeClass('error').addClass('error');						
						return $.mage.__(errorMsg.replace(/&quot;/g, '\"'));
					}	
				}
			});*/
			
			
        }
		
		
);


